#include "libft.h"

void *memchr(const void *s, int c, size_t n)
{
    
}