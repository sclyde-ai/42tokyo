#include <stdio.h>
#include <string.h>

size_t ft_strlen(const char *c);
char *strlcpy(char *dest, const char *src, size_t size)
size_t ft_strlcat(char *dest, const char *src, size_t size);

int main(){


    char *a = "abc";
    char *b = "123456";

    ft_strlcpy(a, b, 5);
    printf("%s", a);
    
}