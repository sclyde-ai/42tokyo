#include <stddef.h>

size_t ft_strlen(const char *c)
{
    size_t l;
    l = 0;

    while(*c++) l++;

    return l;
}


// #include <stdio.h>
// int main()
// {
//     char a = "abcdef";
//     char *char0 = "";

//     printf("%lld\n", ft_strlen(a));
//     printf("%lld\n", ft_strlen(char0));
// }
