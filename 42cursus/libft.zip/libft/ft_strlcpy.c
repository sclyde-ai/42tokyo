#include "libft.h"

size_t ft_strlcpy(char *dest, const char *src, size_t size)
{
    size_t slen = ft_strlen(src);
    size_t i;

    i = 0;
    if(size == 0) return slen;
    while(i < size-1 && i < slen)
    {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
    return slen;
}
