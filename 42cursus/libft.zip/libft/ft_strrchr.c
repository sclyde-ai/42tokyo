#include "libft.h"

char *ft_strrchr(const char *s, int c)
{
    char *ans;

    ans = NULL;
    while(*s)
    {
        if(*s == (char)c) 
            ans = (char *)s;
        s++;
    }

    if(c == 0)
        return (char *)s;
    else
        return ans;
}
