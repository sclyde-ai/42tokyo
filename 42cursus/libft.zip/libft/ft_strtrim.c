#include "libft.h"

char *ft_strtrim(char const *s1, char const *set)
{
    char *p;
    char *start;
    int b;
    size_t i;

    p = (char *)malloc(ft_strlen(s1) + 1);
    if(p == NULL) return NULL;
    start = p;
    while(*s1)
    {
        i = 0;
        b = 0;
        while(i < ft_strlen(set))
        {
            if(*s1 == set[i])
                b = 1;
            i++;
        }
        if(b)
            s1++;
        else
            *p++ = *s1++;
    }
    *p++ = '\0';
    return start;
}

// #include <stdio.h>
// #include <string.h>
// #include <stdlib.h>

// void test_ft_strtrim(const char *s1, const char *set, const char *expected)
// {
//     char *result = ft_strtrim(s1, set);
//     printf("Input string: \"%s\"\n", s1);
//     printf("Set to trim: \"%s\"\n", set);
//     printf("Expected: \"%s\"\n", expected);
//     printf("Result: \"%s\"\n", result);
//     printf("Test %s\n\n", (strcmp(result, expected) == 0) ? "PASSED" : "FAILED");
//     free(result);
// }


// int main()
// {
//     // テストケース1: 基本的なトリミング
//     test_ft_strtrim("   Hello World   ", " ", "Hello World");

//     // テストケース2: 複数の文字をトリミング
//     test_ft_strtrim("...Hello...World...", ".", "Hello...World");

//     // テストケース3: トリミングする文字がない場合
//     test_ft_strtrim("Hello World", "xyz", "Hello World");

//     // テストケース4: 空の文字列
//     test_ft_strtrim("", "abc", "");

//     // テストケース5: すべての文字がトリミング対象
//     test_ft_strtrim("aaabbbaaabbb", "ab", "");

//     // テストケース6: 文字列の先頭のみトリミング
//     test_ft_strtrim("###Hello", "#", "Hello");

//     // テストケース7: 文字列の末尾のみトリミング
//     test_ft_strtrim("Hello###", "#", "Hello");

//     // テストケース8: 複数種類の文字をトリミング
//     test_ft_strtrim("12Hello World21", "123", "Hello World");

//     return 0;
// }