#include "libft.h"

char *ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
    char* p;
    size_t len;
    unsigned int i;

    l = ft_strlen(s);
    p = malloc(sizeof(char *) * (l+1));

    while(*s)
        *p++ = f(i++, *s++);
}