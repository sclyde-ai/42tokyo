#include "libft.h"

char *ft_strjoin(char const *s1, char const *s2)
{
    size_t len1;
    size_t len2;
    char *p;
    size_t i;

    len1 = ft_strlen(s1);
    len2 = ft_strlen(s2);
    p = (char *)malloc(len1+len2+1);
    i = 0;
    while(i < len1)
    {
        p[i] = s1[i];
        i++;
    }
    while(i < len1 + len2)
    {
        p[i] = s2[i - len1];
        i++;
    }
    p[len1 + len2] = '\0';
    return p;
}

// #include <stdio.h>
// #include <string.h>
// #include <stdlib.h>


// // ft_strjoinの実装はここに配置

// void test_ft_strjoin(const char *s1, const char *s2, const char *expected)
// {
//     char *result = ft_strjoin(s1, s2);
//     printf("String 1: \"%s\"\n", s1);
//     printf("String 2: \"%s\"\n", s2);
//     printf("Expected: \"%s\"\n", expected);
//     printf("Result: \"%s\"\n", result);
//     printf("Test %s\n\n", (strcmp(result, expected) == 0) ? "PASSED" : "FAILED");
//     free(result);
// }

// int main()
// {
//     // テストケース1: 基本的な文字列の結合
//     test_ft_strjoin("Hello ", "World", "Hello World");

//     // テストケース2: 空の文字列との結合
//     test_ft_strjoin("", "Test", "Test");

//     // テストケース3: 空の文字列との結合（逆）
//     test_ft_strjoin("Test", "", "Test");

//     // テストケース4: 両方とも空の文字列
//     test_ft_strjoin("", "", "");

//     // テストケース5: 数字を含む文字列の結合
//     test_ft_strjoin("123", "456", "123456");

//     // テストケース6: 特殊文字を含む文字列の結合
//     test_ft_strjoin("Hello!", "?World", "Hello!?World");

//     // テストケース7: 長い文字列の結合
//     test_ft_strjoin("This is a very long string ", "that needs to be joined", 
//                     "This is a very long string that needs to be joined");

//     // テストケース8: スペースを含む文字列の結合
//     test_ft_strjoin("   Hello", "   World   ", "   Hello   World   ");

//     return 0;
// }